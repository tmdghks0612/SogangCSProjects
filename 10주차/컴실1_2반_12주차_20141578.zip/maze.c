#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct{
	int right;
	int below;
	int room;
}maze;

void makesame(maze** m,int prev, int curr, int cur_row, int col){
	int i, j;
	for(i = 0; i<=cur_row; i++){
		for(j = 0; j<col; j++){
			if(m[i][j].room == prev) m[i][j].room = curr;
		}
	}
}

void makeimperfect(maze** m, int row, int col){	
	int i, j;
	int cnt = 0;
	int max;
	if(row>col) max = col/2;
	else max = row/2;
	while(1){
		i = rand()%row;
		j = rand()%col;
	
		if(!m[i][j].right || !m[i][j].below){
			if(j != col-1&& m[i][j].right != 1) {
				m[i][j].right = 1;
				cnt++;
			}
			if(cnt == max)break;
			if(i != row-1&& m[i][j].below != 1 ) {
				m[i][j].below = 1;
				cnt++;
			}
			if(cnt == max) break;
		}
		if(cnt == max) break;
	}
}

int main(){
	maze** m;
	int row, col;
	int i, j;
	int flag = 0;
	int openflag = 0;
	FILE* fp;
	int num = 1;
	int tmp;
	srand(time(NULL));
	printf("Input row col : ");
	scanf("%d %d",&row,&col);
	m = (maze**)calloc(row,sizeof(maze*));
	for(i = 0; i<row; i++)
		m[i] = (maze*)calloc(col,sizeof(maze));

	for(i = 0; i<row; i++)
		for(j = 0; j<col; j++)
			m[i][j].room = num++; 
	
	for(i = 0; i<row; i++){
		for(j = 0; j<col-1; j++){
			flag = rand()%2;
			if(flag && m[i][j+1].room != m[i][j].room){
				tmp = m[i][j+1].room;
				m[i][j+1].room = m[i][j].room;
				m[i][j].right = 1;
				makesame(m,tmp,m[i][j].room,i,col);
			}
			if(i == row-1 && m[i][j+1].room != m[i][j].room){
				tmp = m[i][j+1].room;
				m[i][j+1].room = m[i][j].room;
				m[i][j].right = 1;
				makesame(m,tmp,m[i][j].room,i,col);
			}
		}
		if(i == row-1) break;
		openflag = 0;
		for(j = 0; j<col; j++){
			flag = rand()%2;
			if(j>0 && m[i][j].room != m[i][j-1].room) openflag = 0;
			if(flag){
				m[i+1][j].room = m[i][j].room;
				m[i][j].below = 1;
				openflag = 1;
			}
			if(!openflag){
				if(j<col-1&& m[i][j+1].room != m[i][j].room){
					m[i+1][j].room = m[i][j].room;
					m[i][j].below = 1;
				}
				else if(j == col-1){
					m[i+1][j].room = m[i][j].room;
					m[i][j].below = 1;
				}
			}
		}
	}
	makeimperfect(m,row,col);
	fp = fopen("result.maz","w");
	fprintf(fp,"+");
	for(i = 0; i<row; i++)fprintf(fp,"-+");
	fprintf(fp,"\n");
	for(i = 0; i<row; i++){
		fprintf(fp,"|");
		for(j = 0; j<col; j++){
			if(m[i][j].right) fprintf(fp,"  ");
			else fprintf(fp," |");
		}
		fprintf(fp,"\n+");
		for(j = 0; j<col; j++){
			if(m[i][j].below) fprintf(fp," +");
			else fprintf(fp,"-+");
		}
		fprintf(fp,"\n");
	}
	fclose(fp);
	for(i = 0; i<row; i++)
		free(m[i]);
	free(m);
	return 0;
}
