﻿#include "tetris.h"
static struct sigaction act, oact;

void confirm();
int cnt = 1;

int main(){
	int exit=0;
	
	createRankList();
	initscr();
	noecho();
	keypad(stdscr, TRUE);	
	
	recRoot = (RecNode*)malloc(sizeof(RecNode));
	recRoot->lv = 0;
	recRoot->parent = NULL;
	recRoot->score = 0;
	CreateRec(recRoot);

	srand((unsigned int)time(NULL));

	while(!exit){
		recommendX = 0;
		recommendY = 0;
		recommendR = 0;
		clear();
		switch(menu()){
		case MENU_PLAY: play(); break;
		case MENU_RANK: rank(); break;
		case MENU_RECM: recommendedPlay(); break;
		case MENU_EXIT: exit=1; break;
		default: break;
		}
	}

	endwin();
	system("clear");
	return 0;
}

void confirm(){
/*	if(recRoot->child->child->child->lv == 1){
		while(1){
			printf("In %d count!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",cnt);
		}
	}
	*/
}

void InitTetris(){
	int i,j;

	for(j=0;j<HEIGHT;j++)
		for(i=0;i<WIDTH;i++)
			field[j][i]=0;
	
	for(i = 0; i<BLOCK_NUM; i++)
		nextBlock[i]=rand()%7;
		
	recommend(recRoot);

	blockRotate=0;
	blockY=-1;
	blockX=WIDTH/2-2;
	score=0;	
	gameOver=0;
	timed_out=0;

	DrawOutline();
	DrawField();
	DrawBlockWithFeatures(blockY,blockX,nextBlock[0],blockRotate);
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

void DrawOutline(){	
	int i,j;
	/* 블럭이 떨어지는 공간의 태두리를 그린다.*/
	DrawBox(0,0,HEIGHT,WIDTH);

	/* next block을 보여주는 공간의 태두리를 그린다.*/
	move(2,WIDTH+10);
	printw("NEXT BLOCK");
	DrawBox(3,WIDTH+10,4,8);
	move(9,WIDTH+10);
	DrawBox(10,WIDTH+10,4,8);
	/* score를 보여주는 공간의 태두리를 그린다.*/
	move(16,WIDTH+10);
	printw("SCORE");
	DrawBox(17,WIDTH+10,1,8);
}

int GetCommand(){
	int command;
	command = wgetch(stdscr);
	switch(command){
	case KEY_UP:
		break;
	case KEY_DOWN:
		break;
	case KEY_LEFT:
		break;
	case KEY_RIGHT:
		break;
	case ' ':	/* space key*/
		/*fall block*/
		break;
	case 'q':
	case 'Q':
		command = QUIT;
		break;
	default:
		command = NOTHING;
		break;
	}
	return command;
}

int ProcessCommand(int command){
	int ret=1;
	int drawFlag=0;
	switch(command){
	case QUIT:
		ret = QUIT;
		break;
	case KEY_UP:
		if((drawFlag = CheckToMove(field,nextBlock[0],(blockRotate+1)%4,blockY,blockX)))
			blockRotate=(blockRotate+1)%4;
		break;
	case KEY_DOWN:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)))
			blockY++;
		break;
	case KEY_RIGHT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX+1)))
			blockX++;
		break;
	case KEY_LEFT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX-1)))
			blockX--;
		break;
	case ' ':
		while(CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)) blockY++;
		drawFlag == 1;
	default:
		break;
	}
	if(drawFlag) DrawChange(field,command,nextBlock[0],blockRotate,blockY,blockX);
	return ret;	
}

void DrawField(){
	int i,j;
	for(j=0;j<HEIGHT;j++){
		move(j+1,1);
		for(i=0;i<WIDTH;i++){
			if(field[j][i]==1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(".");
		}
	}
}


void PrintScore(int score){
	move(18,WIDTH+11);
	printw("%8d",score);
}

void DrawNextBlock(int *nextBlock){
	int i, j;
	for( i = 0; i < 4; i++ ){
		move(4+i,WIDTH+13);
		for( j = 0; j < 4; j++ ){
			if( block[nextBlock[1]][0][i][j] == 1 ){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
	for(i = 0; i<4; i++){
		move(11+i,WIDTH+13);
		for(j = 0; j<4; j++){
			if(block[nextBlock[2]][0][i][j] == 1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
}

void DrawBlock(int y, int x, int blockID,int blockRotate,char tile){
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(block[blockID][blockRotate][i][j]==1 && i+y>=0){
				move(i+y+1,j+x+1);
				attron(A_REVERSE);
				printw("%c",tile);
				attroff(A_REVERSE);
			}
		}

	move(HEIGHT,WIDTH+10);
}

void DrawBox(int y,int x, int height, int width){
	int i,j;
	move(y,x);
	addch(ACS_ULCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for(j=0;j<height;j++){
		move(y+j+1,x);
		addch(ACS_VLINE);
		move(y+j+1,x+width+1);
		addch(ACS_VLINE);
	}
	move(y+j+1,x);
	addch(ACS_LLCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play(){
	int command;
	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	do{
		if(timed_out==0){
			alarm(1);
			timed_out=1;
		}
		command = GetCommand();
		if(ProcessCommand(command)==QUIT){
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();
			
			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
	noecho();
}

char menu(){
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

int CheckToMove(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	int i, j;
	for(i = 0; i<4; i++){
		for(j = 0; j<4; j++){
			if(block[currentBlock][blockRotate][i][j] == 1 && f[blockY+i][blockX+j] != 0) return 0;
			if(block[currentBlock][blockRotate][i][j] == 1 && (blockY+i) >= HEIGHT) return 0;
			if(block[currentBlock][blockRotate][i][j] == 1 && (blockX+j) < 0) return 0;
			if(block[currentBlock][blockRotate][i][j] == 1 && (blockX+j) >= WIDTH) return 0;
		}
	}
	return 1;
}

void DrawChange(char f[HEIGHT][WIDTH],int command,int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	int i, j;
	int pre_y=blockY, pre_x=blockX, pre_rot=blockRotate;
	int shadowY;
	switch(command){
		case KEY_LEFT:
			pre_x = blockX+1;
			break;

		case KEY_RIGHT:
			pre_x = blockX-1;
			break;

		case KEY_DOWN:
			pre_y = blockY-1;
			break;
		case KEY_UP:
			if(blockRotate-1<0)
				pre_rot = 3;
			else	pre_rot = blockRotate-1;
			break;
	}

	shadowY = pre_y;
	while(CheckToMove(f,currentBlock,pre_rot,shadowY+1,pre_x))shadowY++;
	for(i = 0; i<4; i++){
		for(j = 0 ;j<4; j++){
			if(block[currentBlock][recommendR][i][j] == 1){
				move(recommendY+i+1,recommendX+j+1);
				printw(".");
			}
			if(block[currentBlock][pre_rot][i][j] == 1) {
				move(pre_y+i+1,pre_x+j+1);
				printw(".");
				move(shadowY+i+1,pre_x+j+1);
				printw(".");
			}
		}
	}

	DrawBlockWithFeatures(blockY,blockX,currentBlock,blockRotate);
}

void BlockDown(int sig){
	// user code
	int i,j;
	if(CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX))
		DrawChange(field, KEY_DOWN, nextBlock[0], blockRotate, ++blockY,blockX);
	else{
		if(blockY == -1) gameOver = 1;
		score += AddBlockToField(field,nextBlock[0],blockRotate,blockY,blockX);
		score += DeleteLine(field,1);
		for(i = 0; i<BLOCK_NUM-1; i++)
			nextBlock[i] = nextBlock[i+1];
		nextBlock[BLOCK_NUM-1] = rand()%7;
		for(i = 0; i<HEIGHT; i++)
			for(j = 0; j<WIDTH; j++)
				recRoot->f[i][j] = field[i][j];
		//fieldcopy(field,recRoot->f);
		recRoot->score = 0;
		recommendY = -1;	
		recommend(recRoot);
		blockRotate=0;
		blockY=-1;
		blockX=WIDTH/2-2;
		DrawNextBlock(nextBlock);
		PrintScore(score);
	}
	timed_out = 0;
}

int AddBlockToField(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	int i, j, cnt = 0;
	for(i = 0; i<4; i++){
		for(j = 0; j<4; j++){
			if(block[currentBlock][blockRotate][i][j] == 1) {
				if(blockY+i+1 == HEIGHT||f[blockY+i+1][blockX+j] == 1) cnt++;
				f[blockY+i][blockX+j] = 1;
			}
		}
	}
	return cnt*10;
}

int DeleteLine(char f[HEIGHT][WIDTH], int dfflag){
	// user code
	int i = HEIGHT-1, j, k;
	int cnt = 0, flag, blankflag;
	while(i>=0){	
		flag = 0;
		blankflag = 0;
		for(j = 0; j<WIDTH; j++){
			if(f[i][j] == 1)	flag++;
			else blankflag++;
		}
		if(flag == WIDTH){
			cnt++;
			for(j = 0; j<WIDTH; j++)
				f[i][j] = 0;
			for(k = i-1; k>=0; k--)
				for(j = 0; j<WIDTH; j++)
					f[k+1][j] = f[k][j];
		}
		else i--;
		if(blankflag == WIDTH) break;
	}
	if(dfflag) DrawField(); 
	return cnt*cnt*100;
}

void DrawShadow(int y, int x, int blockID,int blockRotate){
	// user code
	int shadowY = y;
	while(CheckToMove(field,blockID,blockRotate,shadowY+1,x))shadowY++;
	DrawBlock(shadowY,x,blockID,blockRotate,'/');
}

void DrawBlockWithFeatures(int y, int x, int blockID, int blockRotate){
	DrawBlock(y,x,blockID,blockRotate,' ');
	DrawRecommend(recommendY, recommendX, blockID, recommendR);
	DrawShadow(y,x,blockID,blockRotate);
}

void createRankList(){
	// user code
	FILE* fp = fopen("rank.txt","r");
	int i;
	user* list;
	if(fp == NULL) return;
	fscanf(fp,"%d",&user_max);
	list = (user_pointer)malloc(sizeof(user)*user_max);
	for(i = 0; i<user_max; i++){
		fscanf(fp,"%s %d",list[i].name,&list[i].score);
	}
	head = makeBST(list,0,user_max-1);
	fclose(fp);
}

user_pointer makeBST(user* list, int start, int end){
	int mid = (start+end)/2;
	user_pointer tmp = (user_pointer)malloc(sizeof(user));
	tmp->score = list[mid].score;
	strcpy(tmp->name,list[mid].name);
	tmp->left = NULL;
	tmp->right = NULL;

	if(start>end)
		return NULL;
	
	tmp->right = makeBST(list,mid+1,end);
	tmp->left = makeBST(list,start,mid-1);
	return tmp;
}

void rank(){
	// user code
	char command;
	char strX[11], strY[11], strRank[11];
	char name[NAMELEN];
	int X, Y, ranking;
	clear();
	printw("1. list ranks from X to Y\n");
	printw("2. list ranks by a specific name\n");
	printw("3. delete a specific rank\n");
	refresh();
	command = wgetch(stdscr);
	echo();
	switch(command){
		case '1':
			printw("X: ");
			refresh();
			getstr(strX);
			printw("Y: ");	
			refresh();
			getstr(strY);
			X = atoi(strX);
			if(strX[0] == '\0') X = 1;
			Y = atoi(strY);
			if(strY[0] == '\0') Y = user_max;
			rank_menu1(X,Y);
			break;
		case '2':
			printw("Input the name: ");
			refresh();
			getstr(name);
			refresh();
			rank_menu2(name);
			break;
		case '3':
			printw("Input the rank: ");
			refresh();
			getstr(strRank);
			ranking = atoi(strRank);
			refresh();
			rank_menu3(ranking);
			break;
	}
	noecho();
}

void insert_BST(user insert){
	user_pointer index = head;
	user_pointer tmp = (user_pointer)malloc(sizeof(user));
	*tmp = insert;
	tmp->left = NULL;
	tmp->right = NULL;

	if(head == NULL){
		head = tmp;
	}
	else{
		while(1){
			if(tmp->score >= index->score){
				if(index->left){
					index = index->left;
					continue;
				}
				else{
					index->left = tmp;
					break;
				}
			}
			else{
				if(index->right){
					index = index->right;
					continue;
				}
				else{
					index->right = tmp;
					break;
				}
			}
		}
	}
}

void print_BST(user_pointer usr_ptr, int X, int Y, int* cnt){
	if(usr_ptr){
		print_BST(usr_ptr->left,X,Y,cnt);
		if((*cnt+1)>=X && (*cnt+1)<=Y) {
			printw(" %-17s| %d\n",usr_ptr->name,usr_ptr->score);
		}
		(*cnt)++;
		print_BST(usr_ptr->right,X,Y,cnt);
	}
}

int search_BST(user_pointer usr_ptr, char* name){
	int index = 0;
	if(usr_ptr){
		index += search_BST(usr_ptr->left,name);
		if(strcmp(name,usr_ptr->name) == 0){
			index = 1;
			printw(" %-17s| %d\n",usr_ptr->name, usr_ptr->score);
		}
		index += search_BST(usr_ptr->right,name);
	}
	return index;
}


//왼쪽 0 오른쪽 1
void delete_BST(user_pointer usr_ptr, int target, int* cnt, int* flag,user_pointer parent, int index){
	if(usr_ptr){
		delete_BST(usr_ptr->left,target,cnt,flag,usr_ptr,0);
		(*cnt)++;
		if((*cnt) == target){
			user_pointer maximum = usr_ptr->left;
			user_max--;
			if(usr_ptr->left == NULL && usr_ptr->right == NULL){
				free(usr_ptr);
				if(index == 0) {
					parent->left = NULL;
				}
			  else if(index == 1) {
					parent->right = NULL;
				}
			}
			else if(usr_ptr->left == NULL){
				user_pointer tmp = usr_ptr;
				if(index == 0) parent->left = usr_ptr->right;
				else if(index == 1)parent->right = usr_ptr->right;
				free(tmp);
			}
			else{
				user_pointer prev = NULL;
				while(maximum->right){
					prev = maximum;
					maximum = maximum->right;
				}
				if(prev){
					usr_ptr->score = maximum->score;
					strcpy(usr_ptr->name,maximum->name);
					free(maximum);
					prev->right = NULL;
				}
				else{
					if(usr_ptr->right)
						maximum->right = usr_ptr->right;
					user_pointer tmp = usr_ptr;
					usr_ptr = maximum;
					free(tmp);
				}
			}	
			*flag = 1;
		}
		delete_BST(usr_ptr->right,target,cnt,flag,usr_ptr,1);
	}
}
void read_BST(user_pointer usr_ptr, user_pointer* list, int* cnt){
	if(usr_ptr != NULL){
		read_BST(usr_ptr->left,list,cnt);
		++(*cnt);
		if(*cnt == 1) *list = (user_pointer)malloc(sizeof(user));
		else *list = (user_pointer)realloc(*list,sizeof(user)*(*cnt));
		(*list)[*cnt-1] = *usr_ptr;
		read_BST(usr_ptr->right,list,cnt);
	}
}

void rank_menu1(int X, int Y){
	int cnt = 0;
	printw("       name       |   score   \n");
	printw("==============================\n");
	refresh();
	if(X>Y||Y>user_max||X>user_max){
		printw("\nsearch failure: no rank in the list\n");
		refresh();
		getchar();
		return;
	}
	print_BST(head,X,Y,&cnt);
	refresh();
	getchar();
}

void rank_menu2(char* name){
	int index;
	printw("       name       |   score   \n");
	printw("==============================\n");
	refresh();
	index = search_BST(head,name);
	if(!index) printw("\nsearch failure : no name in the list");
	refresh();
	getchar();
}

void rank_menu3(int target){
	int cnt = 0;
	int index = 0;
	delete_BST(head,target,&cnt,&index,NULL, -1);
	if(index) printw("\nresult :  the rank deleted\n");
	else printw("\nsearch failure: the rank not in the list\n");
	refresh();
	writeRankFile();
	getchar();
}

void writeRankFile(){
	// user code
	int cnt = 0, i, j;
	user* list;
	FILE* fp = fopen("rank.txt","w");

	read_BST(head,&list,&cnt);
	fprintf(fp,"%d\n",cnt);
	for(i = 0; i<cnt; i++)
		fprintf(fp,"%s %d\n",list[i].name,list[i].score);
	fclose(fp);
	free(list);
}

void newRank(int score){
	// user code
	user u;
	clear();
	printw("your name: ");
	refresh();
	echo();
	getstr(u.name);
	noecho();
	
	u.score = score;
	insert_BST(u);
	user_max++;	
	writeRankFile();

}

void DrawRecommend(int y, int x, int blockID,int blockRotate){
	// user code
	DrawBlock(y,x,blockID,blockRotate,'R');	
}

int recommend(RecNode *root){
	int max=0; // 미리 보이는 블럭의 추천 배치까지 고려했을 때 얻을 수 있는 최대 점수
	int c = 0;
	int rot, j;
	int a, b;
	int x = 1, y = 0;
	int score = 0;

	if(root->child) {
		switch(nextBlock[root->lv]){
			case 0: //2개
				root->childnum = 17;
				break;
			case 1: //4개
			case 2:
			case 3:
				root->childnum = 34;
				break;
			case 4: //1개
				root->childnum = 9;
				break;
			case 5: //2개
			case 6: //2개
				root->childnum = 17;
				break;
		}
		for(rot = 0; rot<4; rot++){
			while(CheckToMove(root->f, nextBlock[root->lv], rot, y, x-1)) x--;
			for(j = x; CheckToMove(root->f, nextBlock[root->lv], rot, y, j+1); j++){
				while(CheckToMove(root->f, nextBlock[root->lv], rot, y+1, j)) y++;
				cnt = 9;
				confirm();		//#9
				//score = RecProcess(root->child,j,y,rot,nextBlock[root->lv]);
				for(a = 0; a<HEIGHT; a++)
					for(b = 0; b<WIDTH; b++)
						root->child->f[a][b] = root->f[a][b];

//				fieldcopy(root->f,root->child->f);
				cnt = 13;
				confirm();		//#13
				score = root->child->score 
							= root->score 
							+ AddBlockToField(root->child->f,nextBlock[root->lv],rot,y,j)*10
							+ DeleteLine(root->child->f,0)*100;
		
				score += recommend(root->child);
				if(max <= score){
					max = score;
					if(root->lv == 0 && y >= recommendY){
						recommendR = rot;
						recommendX = j;
						recommendY = y;
					}
				}
				y = -1;
				c++;
				score = 0;
				if(c == root->childnum) return max;
			}
		}	
	}

	return max;
}


void CreateRec(RecNode* parent){
	int lv = parent->lv;
	int i;
	if(lv<BLOCK_NUM){	
		parent->child = (RecNode*)malloc(sizeof(RecNode));
		parent->child->lv = lv+1;
		parent->child->parent = parent;
		CreateRec(parent->child);
	}
	else if(lv == BLOCK_NUM) {
		parent->child = NULL;
		parent->childnum = -1;
	}
}

void recommendedPlay(){
	// user code
	int command;
	clear();
	InitTetris();
	do{
		recommend(recRoot);
		blockX = recommendX;
		blockY = recommendY;
		blockRotate = recommendR;
		
		BlockDown(0);
	}while(!gameOver);

	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
	noecho();
}
